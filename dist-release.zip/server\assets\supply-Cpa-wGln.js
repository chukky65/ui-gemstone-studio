import { T as jsxRuntimeExports } from "./worker-entry-CxYEulTY.js";
import { L as Link } from "./router-Dbne1WUM.js";
import { T as TopBar, H as Header, S as SectionFlow, a as Section, F as Footer, u as useToneTokens, b as SectionHeading } from "./Section-DwmYnCaZ.js";
import { P as PageHero } from "./PageHero-BbZQIVuv.js";
import "node:events";
import "node:async_hooks";
import "node:stream/web";
import "node:stream";
const METHODS = [{
  c: "A",
  a: "ICS",
  t: "International Competitive Supply",
  active: false
}, {
  c: "B",
  a: "D&IDPOG",
  t: "Direct & Indirect Purchase of Goods",
  active: false
}, {
  c: "C",
  a: "SSP",
  t: "Sole Source Purchase",
  active: true
}];
const SUPPLY_SECTORS = [{
  n: "01",
  t: "Hospitals & Maternity",
  d: "Medical organisations & health systems"
}, {
  n: "02",
  t: "Construction Companies",
  d: "Building & infrastructure firms"
}, {
  n: "03",
  t: "Raw Materials",
  d: "Producing & extracting companies"
}, {
  n: "04",
  t: "Agricultural Inputs & Outputs",
  d: "Agro processing & farming organisations"
}, {
  n: "05",
  t: "Amusement & Recreation",
  d: "Parks & recreational agencies"
}, {
  n: "06",
  t: "Consumer Electronics & Apparel",
  d: "Consumer goods & lifestyle products"
}, {
  n: "07",
  t: "Vehicle Parts & Accessories",
  d: "Automotive components & parts"
}, {
  n: "08",
  t: "Sports & Entertainment",
  d: "Sporting goods & entertainment supply"
}, {
  n: "09",
  t: "Industrial Machinery",
  d: "Heavy equipment & machinery supply"
}, {
  n: "10",
  t: "Home & Garden",
  d: "Household goods & garden products"
}, {
  n: "11",
  t: "Fruits, Seeds & Produce",
  d: "Agricultural produce & seeds"
}, {
  n: "12",
  t: "SkinCare & Health Products",
  d: "Personal health & wellness supply"
}];
const PARTNERS = [{
  t: "UNDP / GEF-SGP",
  d: "UN Development Programme"
}, {
  t: "AfDB / DFID",
  d: "African Development Bank & UK Aid"
}, {
  t: "USAID",
  d: "US Agency for International Development"
}, {
  t: "UKSAID",
  d: "UK Strategic Aid Programme"
}, {
  t: "UNICEF",
  d: "UN Children's Fund"
}, {
  t: "IMF",
  d: "International Monetary Fund"
}, {
  t: "World Bank",
  d: "International Bank for Reconstruction"
}, {
  t: "State Foreign Aid",
  d: "Bilateral state aid programmes"
}, {
  t: "Domestic Loans",
  d: "Government of Ghana financing"
}];
const STEPS = [{
  c: "A",
  t: "Submit Your Quotation Invoice",
  d: "As a supplier, you may have received an email from our accredited agent or directly from GDSP, containing the product names, quantity and specifications. Prepare and submit your offer or quotation invoice to GDSP's email addresses."
}, {
  c: "B",
  t: "Offer Pre-Evaluation Process (OPEP)",
  d: "GDSP's Evaluation Team will carry out an Offer Pre-Evaluation Process (OPEP). If the offer meets criteria, the team will issue an Acknowledgment Letter, Customer Reference and File Numbers, along with Supply Validation Forms."
}, {
  c: "C",
  t: "Final Assessment Supply Evaluation (FASE) — 12 to 48 Hours",
  d: "Between 12 to 48 hours after the filled Validation Forms are received, the team will carry out a Final Assessment Supply Evaluation (FASE) on the filled forms alongside the supplier's quotation invoices."
}, {
  c: "D",
  t: "Supply Approval — Official Confirmation Letter",
  d: "If your invoice receives general acceptance, FASE members issue an Official Confirmation Supply Approval Letter, followed by a personal telephone call from Dr. Kennedy Ofori, Projects Director — GDSP."
}, {
  c: "E",
  t: "Contact Your Local Agent",
  d: "The approved supplier is expected to contact the local agent by providing the Registration/Validation Cost as stated on the Validation Forms, along with one of their company certificates and quotation invoice."
}, {
  c: "F",
  t: "Purchase Order Issued & Payment Transferred",
  d: "After Supply Validation, the Supplier's Purchase Order, Payment Details and stamped Quotation Invoice are released. The bank will transfer 80% of the supply payment to the supplier's bank account. The remaining 20% is paid before shipment."
}];
const TERMS = [{
  t: "Product Packaging",
  d: "According to your company's original export packaging standards."
}, {
  t: "Supply Terms",
  d: "Price should be quoted on: CIF or FOB"
}, {
  t: "Final Shipment Destination",
  d: "Tema Harbour Seaport, Republic of Ghana"
}, {
  t: "Payment Method",
  d: "Bank to Bank Wire Transfer (T.T) — confirmed by your bank before production starts."
}, {
  t: "Payment Terms",
  d: "80% down payment to start production. 20% paid when product is ready for shipment."
}, {
  t: "Inspection",
  d: "SGS to confirm quantity at port of lading. Cost to be paid by the buyer."
}, {
  t: "Delivery Time",
  d: "Maximum 360 days from the date the 80% advance payment is received by the supplier."
}, {
  t: "Currency",
  d: "Invoice submitted currency: US Dollars or Euro only."
}, {
  t: "Supply Payment Duration",
  d: "80% supply payment within 4–5 working days from invoice approval, after supply validation is completed."
}, {
  t: "Purchase Order",
  d: "Will be issued immediately after supply validation is completed."
}, {
  t: "Shipment Condition",
  d: "Partial supply is accepted but cannot be more than 5 or 6 shipments."
}, {
  t: "Caution Notice",
  d: "If approved, you must complete Supply Validation within THREE DAYS from the date of approval."
}];
function SupplyPage() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-dvh bg-night text-bone", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(TopBar, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Header, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHero, { eyebrow: "Procurement Framework", breadcrumb: "Supply", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "Supply & ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: "text-gold not-italic", children: "procurement." })
    ] }), intro: "GDSP procures goods and services on behalf of Ghana's public and private sectors — using transparent, accountable procurement methods aligned with international best practice." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "gdsp-bright-band border-b border-night/10", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-[1400px] mx-auto grid grid-cols-2 lg:grid-cols-4 divide-x divide-y lg:divide-y-0 divide-night/15", children: [{
      v: "$375M",
      l: "Max Contract Value"
    }, {
      v: "$350K",
      l: "Min Contract Value"
    }, {
      v: "SSP",
      l: "Primary Method"
    }, {
      v: "80 / 20",
      l: "Payment Split"
    }].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 lg:p-10 hover:bg-white/55 transition-colors", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-[0.3em] text-clay mb-5", children: s.l }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-5xl tabular-nums text-night", children: s.v })
    ] }, s.l)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionFlow, { start: "light", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "spot", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AboutBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { padding: "tight", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MethodsBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "spot", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SectorsBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { padding: "tight", children: /* @__PURE__ */ jsxRuntimeExports.jsx(PartnersBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "grid", children: /* @__PURE__ */ jsxRuntimeExports.jsx(StepsBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { padding: "tight", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TermsBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { className: "text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CTABlock, {}) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
function AboutBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-5", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "About Our Supply", children: [
      "How GDSP procures on ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "your behalf." })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `lg:col-span-7 space-y-5 text-lg ${t.textMuted} leading-relaxed`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Ghana Development Supply Projects procures products and services on behalf of both private and public sector organisations. All contracts are valued between $350,000 and $375,000,000 USD and are financed in whole or in part with public and private funds." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "GDSP has been assigned responsibility to procure products from verified suppliers and companies for the use of Ghana's healthcare, construction, agricultural, industrial and consumer sectors — ensuring value for money through a rigorous evaluation process." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "The aim is to make judicious use of public funds from capable, reliable and verified companies that can deliver value for money — protecting consumers and the public from uncertified or unauthorised supply sources." })
    ] })
  ] });
}
function MethodsBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Procurement Methods", children: [
      "Three accepted ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "supply methods." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: `mt-4 ${t.textMuted} max-w-3xl mb-16 leading-relaxed`, children: [
      "GDSP accepts quotation invoices through any of the following three procurement frameworks. The active method for current supply orders is",
      " ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: t.accent, children: "SSP — Sole Source Purchase" }),
      "."
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-1 md:grid-cols-3 gap-px ${t.divider} border ${t.border}`, children: METHODS.map((m) => {
      const activeBg = t.tone === "dark" ? "bg-gold text-night" : "bg-clay text-bone";
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `p-10 transition-colors ${m.active ? activeBg : `${t.cardBg} ${t.cardBgHover}`}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center justify-between mb-6 ${m.active ? "opacity-70" : t.textFaint}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-mono uppercase tracking-[0.3em]", children: [
            "Method ",
            m.c
          ] }),
          m.active && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 bg-night text-gold text-[9px] font-mono uppercase tracking-widest", children: "Active" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-display text-6xl mb-4 ${m.active ? "" : t.accent}`, children: m.a }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-xl font-medium ${m.active ? "" : t.text}`, children: m.t })
      ] }, m.c);
    }) })
  ] });
}
function SectorsBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Sectors We Supply", size: "xl", children: [
      "Products procured across ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "12 sectors." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `mt-6 ${t.textMuted} max-w-3xl mb-16 leading-relaxed`, children: "GDSP manages supply contracts across 12 sectors — from healthcare and construction to agricultural inputs and consumer goods." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px ${t.divider} border ${t.border}`, children: SUPPLY_SECTORS.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-8 group ${t.cardBgHover} transition-colors`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-display text-5xl ${t.tone === "dark" ? "text-gold/30 group-hover:text-gold" : "text-clay/40 group-hover:text-clay"} transition-colors mb-3`, children: s.n }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-2xl mb-2 ${t.text}`, children: s.t }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-sm ${t.textMuted}`, children: s.d })
    ] }, s.n)) })
  ] });
}
function PartnersBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-12 mb-16 items-end", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-7", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Funding Partners", children: [
        "Donor & partner ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "organisations." })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `lg:col-span-5 ${t.textMuted} leading-relaxed`, children: "GDSP's supply programmes are supported by a network of international donors, development finance institutions and bilateral partners." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px ${t.divider} border ${t.border} mb-12`, children: PARTNERS.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-8`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-display text-2xl ${t.accent} mb-2`, children: p.t }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-sm ${t.textMuted}`, children: p.d })
    ] }, p.t)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-2 lg:grid-cols-4 divide-x ${t.divider} border ${t.border}`, children: [{
      v: "US$973.6M",
      l: "MoU Agreement Value"
    }, {
      v: "US$756.2M",
      l: "Economic Grant Secured"
    }, {
      v: "US$68.8M",
      l: "Hospital & Farming Projects"
    }, {
      v: "9",
      l: "Donor Partners"
    }].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `p-8 ${t.cardBg}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-display text-3xl ${t.accent} tabular-nums mb-3`, children: s.v }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-widest ${t.textFaint}`, children: s.l })
    ] }, s.l)) })
  ] });
}
function StepsBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Step-by-Step Process", size: "xl", children: [
      "Supply procedures using ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "SSP method." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `mt-6 ${t.textMuted} max-w-3xl mb-16 leading-relaxed`, children: "In accordance with our administrative procedures, GDSP is currently using Sole Source Purchase (SSP). Follow these steps to submit your quotation invoice and complete the supply validation process." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `space-y-px ${t.divider} border ${t.border}`, children: STEPS.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-8 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 ${t.cardBgHover} transition-colors`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `size-16 border-2 ${t.accentBorder} flex items-center justify-center font-display text-3xl ${t.accent}`, children: s.c }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-10", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-3xl mb-4 ${t.text}`, children: s.t }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed`, children: s.d })
      ] })
    ] }, s.c)) })
  ] });
}
function TermsBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Terms & Conditions", size: "xl", className: "mb-16", children: [
      "Supply terms & ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "conditions." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px ${t.divider} border ${t.border}`, children: TERMS.map((trm) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-8`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-widest ${t.accent} mb-3`, children: trm.t }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed`, children: trm.d })
    ] }, trm.t)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `mt-12 border-l-2 ${t.accentBorder} pl-8 py-2`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-widest ${t.accent} mb-2`, children: "Why Validation is Mandatory" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed max-w-4xl`, children: "The purpose of Supply Validation is to protect consumers and the country against the use of imported products from unknown, uncertified or unauthorised companies. Product Registration is a constitutional mandate under the Public Health Act of 1999, Constitution of the Republic of Ghana." })
    ] })
  ] });
}
function CTABlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-6`, children: "Become a Supplier" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: `font-display text-5xl md:text-7xl mb-8 max-w-4xl mx-auto leading-[0.95] ${t.text}`, children: [
      "Ready to submit your ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "quotation?" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} max-w-2xl mx-auto mb-10 leading-relaxed`, children: "Contact GDSP or your accredited agent to begin the supply submission process. Our evaluation team is ready to assess your quotation invoice." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap justify-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: `${t.btnPrimary} px-8 py-5 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Contact GDSP" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/members", className: `${t.btnGhost} px-8 py-5 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Meet Our Board" })
    ] })
  ] });
}
export {
  SupplyPage as component
};
