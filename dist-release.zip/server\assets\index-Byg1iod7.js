import { T as jsxRuntimeExports } from "./worker-entry-CxYEulTY.js";
import { h as heroImg, L as Link } from "./router-Dbne1WUM.js";
import { T as TopBar, H as Header, S as SectionFlow, a as Section, F as Footer, u as useToneTokens, b as SectionHeading } from "./Section-DwmYnCaZ.js";
import "node:events";
import "node:async_hooks";
import "node:stream/web";
import "node:stream";
const TICKER = ["MoU signed valued at US$973.6 Million with major donor agencies", "Economic grant of US$756.2 Million to boost trade in West Africa", "US$68.8 Million hospital & farming equipment supply project underway", "Partnership with USAID, WHO, UNICEF, AfDB, DFID and World Bank confirmed"];
const PROJECTS = [{
  n: "01",
  t: "Infrastructure",
  d: "We oversee infrastructure development projects — logistics & supplies — for investors driving projects across the African continent."
}, {
  n: "02",
  t: "Consumables",
  d: "Coordination of development projects for consumables for foreign investors to meet local impact and livelihood aid objectives."
}, {
  n: "03",
  t: "Health",
  d: "Health is a major priority. We work with financing partners to make healthcare systems reach the desired project levels for communities."
}, {
  n: "04",
  t: "SkinCare",
  d: "We oversee the supply of sustainable and safe skincare products, connecting verified suppliers across the African continent."
}];
const SECTORS_LIST = ["Hospitals, Maternity & Medical Organisations", "Construction & Building Companies", "Raw Materials & Extracting Companies", "Agricultural Inputs & Output Organisations", "Amusement Park / Recreational Agencies", "Consumer Items, Electronics & Apparel", "Vehicle Parts & Accessories", "Sports & Entertainment", "Industrial Machinery", "Home & Garden, Fruits, Seeds"];
const PARTNERS = ["Domestic Loans", "UNDP / GEF-SGP", "AfDB / DFID", "USAID", "UKSAID", "UNICEF", "IMF", "World Bank", "State Foreign Aid"];
const SERVICES = [{
  n: "01",
  t: "Market & Trade Development",
  d: "Unfamiliar markets in West Africa hold great opportunities. We provide effective B2B trade services targeting South Africa, Angola, Nigeria, Ghana and China — built on reliable, up-to-date market intelligence."
}, {
  n: "02",
  t: "Marketing Consultancy",
  d: "Excellent sales requires an excellent marketing plan. We provide efficient marketing schemes and consumer usage strategies that increase sales and revenue, turning your belief in your product into enduring reality."
}, {
  n: "03",
  t: "Strategic Partnership",
  d: "Going into strategic partnership with us is a blueprint for success. We combine expertise, know-how and resources skillfully to achieve common goals — grounded in integrity, trust, dedication and mutual respect."
}, {
  n: "04",
  t: "Resource Management",
  d: "Our aim is to support you in strengthening efficiency and sustainability. We reduce your workload while constantly providing market information, analysis and projections — keeping you current with target market developments."
}];
const AGENTS = [{
  i: "MK",
  n: "Mr. Martin Kofi"
}, {
  i: "AN",
  n: "Mr. Albert Nkrumah"
}, {
  i: "SK",
  n: "Mr. Steven Kwasi"
}, {
  i: "CD",
  n: "Mr. Charles Danso"
}, {
  i: "PK",
  n: "Mr. Paul Kojo"
}, {
  i: "PA",
  n: "Mr. Peter Appiah"
}, {
  i: "DK",
  n: "Mr. Daniel Kelvin"
}, {
  i: "GA",
  n: "Miss. Gloria Amah"
}, {
  i: "PN",
  n: "Miss. Patricia Nana"
}, {
  i: "MN",
  n: "Mr. Martin Nkrumah"
}];
function Home() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-dvh bg-night text-bone", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(TopBar, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Header, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative overflow-hidden border-b border-line", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: heroImg, alt: "Aerial view at dusk of a West African port with cargo cranes, modern infrastructure buildings, and golden agricultural fields stretching to the horizon", width: 1920, height: 1080, className: "absolute inset-0 w-full h-full object-cover opacity-50" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-r from-night via-night/85 to-night/30" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-night via-night/40 to-transparent" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 gdsp-grain opacity-60 pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative px-6 lg:px-10 pt-20 lg:pt-28 pb-20 max-w-[1400px] mx-auto", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mb-10 text-gold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-px bg-gold" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-mono uppercase tracking-[0.4em]", children: "Infrastructure & Logistics" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "gdsp-rise font-display text-6xl sm:text-7xl md:text-8xl lg:text-[10rem] leading-[0.88] tracking-[-0.02em] max-w-6xl", children: [
          "Building Africa's ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: "text-gold not-italic font-normal", children: "development" }),
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "italic", children: "future." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-14 grid grid-cols-1 lg:grid-cols-12 gap-10 items-end", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "lg:col-span-5 text-lg text-bone/80 leading-relaxed max-w-md", children: [
            "A sovereign procurement authority overseeing infrastructure, healthcare, agriculture and consumables across West Africa — connecting verified suppliers to",
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-bone", children: "553 million people" }),
            "."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-4 flex flex-wrap gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/supply", className: "bg-gold text-night px-7 py-4 text-[11px] font-bold uppercase tracking-[0.2em] flex items-center gap-3 hover:bg-bone transition-colors", children: [
              "Explore Supply ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "→" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/profile", className: "border border-bone/30 text-bone px-7 py-4 text-[11px] font-bold uppercase tracking-[0.2em] hover:border-gold hover:text-gold transition-colors backdrop-blur-sm", children: "Our Profile" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-3 lg:text-right text-[10px] font-mono uppercase tracking-widest text-bone/50 leading-relaxed", children: [
            "Vol. 11 · 04 / 2026",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "Republic of Ghana"
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "gdsp-bright-band border-b border-night/10", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-[1400px] mx-auto grid grid-cols-2 lg:grid-cols-4 divide-x divide-y lg:divide-y-0 divide-night/15", children: [{
      l: "MoU Value",
      v: "$973.6",
      s: "M"
    }, {
      l: "People Served",
      v: "553",
      s: "M+"
    }, {
      l: "Accredited Agents",
      v: "10",
      s: "+"
    }, {
      l: "Partnership",
      v: "5",
      s: " yr"
    }].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 lg:p-10 hover:bg-white/55 transition-colors group", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-[0.3em] text-clay mb-5", children: s.l }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-display text-5xl lg:text-6xl tabular-nums text-night", children: [
        s.v,
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-night/40", children: s.s })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 h-px w-8 bg-clay/45 group-hover:w-full transition-all duration-700" })
    ] }, s.l)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "bg-gold text-night border-b border-night/20 overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-6 py-4 bg-night text-gold text-[10px] font-mono uppercase tracking-[0.3em] flex-shrink-0 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "size-1 rounded-full bg-gold animate-pulse" }),
        "Latest"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden flex-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-12 py-4 whitespace-nowrap gdsp-marquee", children: [...TICKER, ...TICKER, ...TICKER].map((t, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-sm font-medium tracking-wide flex items-center gap-12", children: [
        t,
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-night/40", children: "●" })
      ] }, i)) }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionFlow, { start: "light", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "spot", children: /* @__PURE__ */ jsxRuntimeExports.jsx(WelcomeBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { padding: "tight", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ProjectsBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "spot", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SectorsBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "grid", children: /* @__PURE__ */ jsxRuntimeExports.jsx(QuoteBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(WatchBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { padding: "tight", atmosphere: "grid", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ServicesBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AgentsBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "grid", children: /* @__PURE__ */ jsxRuntimeExports.jsx(VisionBlock, {}) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
function WelcomeBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-12 items-start", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-5", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `border ${t.border} p-10 ${t.softCardBg} backdrop-blur-sm`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-4`, children: "GDSP At a Glance" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-4xl mb-4 ${t.text}`, children: "Procurement with Purpose" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed mb-10`, children: "Serving public & private sectors across West Africa with transparency, accountability and efficiency." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-2 gap-px ${t.divider}`, children: [{
        v: "$973M+",
        l: "Total MoU Value"
      }, {
        v: "553M+",
        l: "People Served"
      }, {
        v: "10+",
        l: "Accredited Agents"
      }, {
        v: "2020",
        l: "MoU Signed"
      }].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-5`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-display text-2xl ${t.accent} tabular-nums`, children: s.v }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-widest ${t.textFaint} mt-1`, children: s.l })
      ] }, s.l)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-7", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Welcome to GDSP", children: [
        "Ghana Development ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "Supply Projects." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `mt-10 space-y-5 text-lg ${t.textMuted} leading-relaxed`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "GDSP has been assigned the responsibility to procure various products from verified suppliers and companies on behalf of both private and public sector organisations across Ghana and West Africa." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Our mandate covers a wide range of sectors, from hospital equipment and agricultural inputs to construction materials and consumer goods — all managed with a commitment to fairness, transparency and value for public funds." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 flex flex-wrap gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/profile", className: `${t.btnPrimary} px-7 py-4 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Read Our Profile" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/supply", className: `${t.btnGhost} px-7 py-4 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Supply Areas" })
      ] })
    ] })
  ] });
}
function ProjectsBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center gap-3 mb-6 ${t.accent}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-8 h-px ${t.tone === "dark" ? "bg-gold" : "bg-clay"}` }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-mono uppercase tracking-[0.4em]", children: "What We Cover" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { size: "xl", className: "mb-16", children: [
      "Discover our ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "projects." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-1 md:grid-cols-2 gap-px ${t.divider} border ${t.border}`, children: PROJECTS.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: `${t.cardBg} p-10 ${t.cardBgHover} transition-colors group relative`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-display text-7xl ${t.tone === "dark" ? "text-gold/30 group-hover:text-gold" : "text-clay/30 group-hover:text-clay"} transition-colors mb-4`, children: p.n }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-3xl mb-4 ${t.text}`, children: p.t }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed`, children: p.d })
    ] }, p.n)) })
  ] });
}
function SectorsBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-7", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Our Mandate", children: "Sectors we serve." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} max-w-2xl my-10 leading-relaxed`, children: "GDSP procures for a broad range of public and private sector organisations, ensuring quality, compliance and value." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: `divide-y ${t.divider} border-y ${t.border}`, children: SECTORS_LIST.map((s, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: `py-5 flex items-center justify-between group transition-colors ${t.tone === "dark" ? "hover:text-gold" : "hover:text-clay"}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-mono ${t.textFaint} tabular-nums`, children: String(i + 1).padStart(2, "0") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-base md:text-lg ${t.text}`, children: s })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `${t.accent} opacity-0 group-hover:opacity-100 transition-opacity`, children: "→" })
      ] }, s)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-5", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `border ${t.border} p-8 ${t.softCardBg} sticky top-28`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-6`, children: "Major Donors & Partners" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-2 gap-px ${t.divider} border ${t.border} mb-8`, children: PARTNERS.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `${t.cardBg} px-4 py-5 text-sm font-medium text-center ${t.text}`, children: p }, p)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-5 pt-2", children: [{
        v: "US$973.6M",
        d: "MoU value signed with international donor agencies and corporate bodies."
      }, {
        v: "US$756.2M",
        d: "Economic grant to strengthen regional stability and trade competitiveness."
      }].map((b) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `border-l-2 ${t.accentBorder} pl-5`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-display text-3xl ${t.accent} tabular-nums`, children: b.v }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-xs ${t.textMuted} mt-1`, children: b.d })
      ] }, b.v)) })
    ] }) })
  ] });
}
function QuoteBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-8`, children: "Statement — Project Director" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("blockquote", { className: `font-display text-4xl md:text-6xl leading-[1.05] max-w-5xl ${t.text}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: t.accent, children: '"' }),
      "The Funds will be used judiciously to cover payment for supplies in ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: t.accent, children: "Health Related Areas" }),
      " — equipping Hospitals, Maternities and Health Centers to fight COVID-19 and beyond.",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: t.accent, children: '"' })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 flex items-center gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `size-14 rounded-full border ${t.accentBorder} flex items-center justify-center font-mono ${t.accent}`, children: "JF" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-medium ${t.text}`, children: "Dr. Joe Forson" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-sm ${t.textMuted} font-mono uppercase tracking-widest text-[11px] mt-1`, children: "Project Director, GDSP · Tamale, Northern Region" })
      ] })
    ] })
  ] });
}
function WatchBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-16 items-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-7 order-2 lg:order-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Watch & Learn", children: [
        "Learn more about our ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "mission & impact." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `mt-8 ${t.textMuted} leading-relaxed mb-5`, children: "Watch our official presentation to understand how GDSP is transforming public procurement in West Africa — ensuring fair evaluation, accountable spending and meaningful impact for communities across the region." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed mb-10`, children: "Our work reaches over 553 million people across the African sub-region, connecting verified suppliers with critical development needs." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/profile", className: `${t.btnPrimary} px-7 py-4 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Our Full Profile" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: `${t.btnGhost} px-7 py-4 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Get Involved" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-5 order-1 lg:order-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "https://www.youtube.com/watch?v=i_WCAKHmLPk", target: "_blank", rel: "noopener noreferrer", className: `block aspect-video relative border ${t.border} ${t.cardBg} group overflow-hidden`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `absolute inset-0 ${t.tone === "dark" ? "gdsp-grid" : "gdsp-light-grid"} opacity-50` }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `size-20 rounded-full ${t.tone === "dark" ? "bg-gold" : "bg-clay"} flex items-center justify-center group-hover:scale-110 transition-transform`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", className: `size-8 ${t.tone === "dark" ? "text-night" : "text-bone"} fill-current ml-1`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M8 5v14l11-7z" }) }) }) })
    ] }) })
  ] });
}
function ServicesBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-12 mb-16 items-end", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-7", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "What We Offer", size: "xl", children: [
        "Strategic ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "services." })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `lg:col-span-5 ${t.textMuted} leading-relaxed`, children: "We go beyond procurement — offering market intelligence, consultancy, partnerships and resource management to drive your success in West African markets." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-1 md:grid-cols-2 gap-px ${t.divider} border ${t.border}`, children: SERVICES.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: `${t.cardBg} p-10 group ${t.cardBgHover} transition-colors`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-baseline justify-between mb-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent}`, children: [
          "Service ",
          s.n
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-display text-5xl ${t.tone === "dark" ? "text-bone/10 group-hover:text-gold/30" : "text-night/10 group-hover:text-clay/40"} transition-colors`, children: s.n })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-3xl mb-4 ${t.text}`, children: s.t }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed mb-6`, children: s.d }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/contact", className: `text-[11px] font-mono uppercase tracking-[0.3em] ${t.accent} inline-flex items-center gap-2 group-hover:gap-4 transition-all`, children: [
        "Learn More ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "→" })
      ] })
    ] }, s.n)) })
  ] });
}
function AgentsBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Officially Recognised", size: "xl", children: [
      "Our accredited ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "agents." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `mt-6 ${t.textMuted} max-w-2xl mb-16 leading-relaxed`, children: "Honoured for their excellent performance in sourcing verified suppliers and delivering real impact across West Africa." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-px ${t.divider} border ${t.border}`, children: AGENTS.map((a) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-6 group ${t.cardBgHover} transition-colors text-center`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `size-16 mx-auto mb-4 border ${t.accentBorder} rounded-full flex items-center justify-center font-mono ${t.accent} transition-colors ${t.tone === "dark" ? "group-hover:bg-gold group-hover:text-night" : "group-hover:bg-clay group-hover:text-bone"}`, children: a.i }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-sm font-medium ${t.text}`, children: a.n }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-widest ${t.textFaint} mt-1`, children: "Accredited" })
    ] }, a.n)) })
  ] });
}
function VisionBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-12 items-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-6`, children: "Vision 2025" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: `font-display text-6xl md:text-8xl leading-[0.9] ${t.text}`, children: [
        "Our ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "vision." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-7", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("blockquote", { className: `font-display text-3xl md:text-4xl leading-[1.15] ${t.text} mb-10 border-l-2 ${t.accentBorder} pl-8`, children: '"A world-class, efficient, transparent, accountable and professionally managed public sector evaluation system in Africa."' }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed`, children: "GDSP aims to be the leading procurement authority in Africa — ensuring consistent attainment of best value for money, supporting national development and fiscal policies, and driving trade competitiveness across the continent to achieve Vision 2025 economic growth as one of Africa's industrialised nations." })
    ] })
  ] });
}
export {
  Home as component
};
