import { T as jsxRuntimeExports } from "./worker-entry-CxYEulTY.js";
import { L as Link } from "./router-Dbne1WUM.js";
import { T as TopBar, H as Header, S as SectionFlow, a as Section, F as Footer, u as useToneTokens, b as SectionHeading } from "./Section-DwmYnCaZ.js";
import { P as PageHero } from "./PageHero-BbZQIVuv.js";
import "node:events";
import "node:async_hooks";
import "node:stream/web";
import "node:stream";
const LEADERS = [{
  i: "KO",
  role: "Projects Director",
  name: "Dr. Kennedy Ofori",
  title: "Ph.D · DFID UK Senior Procurement Specialist",
  creds: ["Ph.D", "MBA", "BSc", "MCIPS"],
  bio: "Dr. Kennedy Ofori is a DFID UK Senior Procurement Specialist currently on secondment to GDSP. He held various procurement positions in the National Health Service from 1990 to 1999, before joining the Department for International Development in 1999 as a Procurement Adviser working across multiple offices in Africa. He has contributed significantly to development in Ghana, Sierra Leone, South Africa, Tanzania, Zambia, Uganda, Zimbabwe, Vietnam and Pakistan.",
  facts: [{
    l: "NHS Experience",
    v: "1990 — 1999"
  }, {
    l: "DFID Joined",
    v: "1999"
  }, {
    l: "Countries Served",
    v: "9+ Nations"
  }, {
    l: "Specialisation",
    v: "Strategic Procurement"
  }]
}, {
  i: "SA",
  role: "Assistant Director",
  name: "Mr. Sam Adams",
  title: "Lawyer · CPA · Chartered Accountant · Former MP",
  creds: ["BBA", "CPA", "CA", "LLB"],
  bio: "Mr. Sam Adams is a Lawyer by profession. He holds a Bachelor of Business Administration (Accounting Major) from the Wharton Business School, University of Pennsylvania (1977), is a member of the AICPA (1979), the Institute of Chartered Accountants Ghana (1993) and the Ghana Institute of Taxation (1986). He served as Member of Parliament for Upper West Akin Constituency for four years and as Executive Secretary to the Revenue Agencies Governing Board.",
  facts: [{
    l: "Wharton School",
    v: "BBA 1977"
  }, {
    l: "CPA",
    v: "AICPA 1979"
  }, {
    l: "Parliament",
    v: "4 Years MP"
  }, {
    l: "IMF / World Bank",
    v: "Oversight Cmte"
  }]
}, {
  i: "SO",
  role: "Administrative Staff",
  name: "Miss. Sophia Osei",
  title: "MSc · MA · Aid & Debt Management Specialist",
  creds: ["MSc", "MA", "BA (Hons)"],
  bio: "Miss Sophia Osei holds a Master's degree (MSc) in Secretary Management from the School of Oriental and African Studies, University of London, and a Master's degree (MA) in Economic Policy Management from the University of Ghana. She has specialised in aid and debt management techniques that enhance aid effectiveness, and has consulted for several organisations and countries including the Commonwealth Secretariat.",
  facts: [{
    l: "SOAS London",
    v: "MSc Sec. Mgmt"
  }, {
    l: "Univ. of Ghana",
    v: "MA Econ. Policy"
  }, {
    l: "Specialisation",
    v: "Aid & Debt Mgmt"
  }, {
    l: "Languages",
    v: "English & French"
  }]
}];
const EVALUATION = [{
  i: "OA",
  n: "Mrs. Olivia Amankwah",
  r: "Evaluation Member",
  d: "Has worked in both the USA and Ghana, bringing several years of cross-border experience. One of her prime responsibilities is the supervision of Value for Money Audits on single-sourced contracts under Ghana's Procurement laws.",
  tags: ["Value for Money Audits", "Procurement Law", "USA & Ghana"]
}, {
  i: "FK",
  n: "Dr. Frimpong Kobby",
  r: "Evaluation Systems Specialist",
  d: "Specialist in Evaluation Systems for GDSP. Held numerous positions in procurement service from 1993 to 2000. Holds a BSc in Development Planning and an MBA specialising in Strategic Planning and Procurement.",
  tags: ["Evaluation Systems", "Strategic Planning", "MCIPS"]
}, {
  i: "GA",
  n: "Gabriel Atta",
  r: "Evaluation Member",
  d: "Serves as an evaluation member on the GDSP board, contributing expertise to the assessment and verification of procurement processes in line with Ghana's public procurement laws.",
  tags: ["Procurement Evaluation", "Contract Assessment"]
}, {
  i: "JM",
  n: "Mr. Joe Mensah",
  r: "Evaluation Member",
  d: "Brings sector-level expertise to GDSP's evaluation committee, participating in the fair and transparent assessment of suppliers, contracts and development programmes.",
  tags: ["Supplier Assessment", "Programme Review"]
}, {
  i: "MA",
  n: "Dr. Michael Atanda",
  r: "Evaluation Member",
  d: "Brings academic and professional credentials to the oversight of procurement procedures. His role encompasses the review and validation of project eligibility, supplier standards and contract compliance.",
  tags: ["Contract Compliance", "Supplier Standards"]
}, {
  i: "JA",
  n: "Rev. Joseph Adechem (Rtd)",
  r: "Evaluation Member (Rtd)",
  d: "Retired member of GDSP's evaluation committee, whose experience in governance, ethics and institutional oversight continues to inform the commission's standards of integrity and impartiality.",
  tags: ["Governance", "Institutional Ethics", "Retired"]
}];
function MembersPage() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-dvh bg-night text-bone", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(TopBar, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Header, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHero, { eyebrow: "Management Board", breadcrumb: "Our Members", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "Our ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: "text-gold not-italic", children: "members." })
    ] }), intro: "Meet the dedicated professionals guiding GDSP — a management board of experienced specialists in procurement, law, finance, evaluation and development." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "bg-night border-b border-line", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-[1400px] mx-auto grid grid-cols-2 lg:grid-cols-4 divide-x divide-y lg:divide-y-0 divide-line", children: [{
      v: "1",
      l: "Project Director"
    }, {
      v: "1",
      l: "Assistant Director"
    }, {
      v: "6",
      l: "Evaluation Members"
    }, {
      v: "—",
      l: "Administrative Staff"
    }].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 lg:p-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-5xl text-gold tabular-nums mb-3", children: s.v }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-widest text-bone/60", children: s.l })
    ] }, s.l)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionFlow, { start: "light", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "spot", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LeadersBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { padding: "tight", atmosphere: "grid", children: /* @__PURE__ */ jsxRuntimeExports.jsx(EvaluationBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { className: "text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CTABlock, {}) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
function LeadersBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Board Composition", size: "xl", children: [
      "Management ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "board." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `mt-6 ${t.textMuted} max-w-3xl mb-16 leading-relaxed`, children: "Our board brings together seasoned professionals from across the public and private sectors — united by a shared commitment to transparent, accountable and effective procurement for Ghana and West Africa." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `space-y-px ${t.divider} border ${t.border}`, children: LEADERS.map((l) => /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: `${t.cardBg} p-10 lg:p-12 grid grid-cols-1 lg:grid-cols-12 gap-10 ${t.cardBgHover} transition-colors`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `size-32 border ${t.accentBorder} rounded-full flex items-center justify-center font-display text-5xl ${t.accent} mb-6`, children: l.i }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-3`, children: l.role }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-3xl mb-2 ${t.text}`, children: l.name }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-sm ${t.textMuted} mb-5`, children: l.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: l.creds.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-mono px-2 py-1 border ${t.border} ${t.accent}`, children: c }, c)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-9", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-lg ${t.textMuted} leading-relaxed mb-8`, children: l.bio }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-2 lg:grid-cols-4 gap-px ${t.divider} border ${t.border}`, children: l.facts.map((f) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-5`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-widest ${t.textFaint} mb-2`, children: f.l }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-display text-xl ${t.accent}`, children: f.v })
        ] }, f.l)) })
      ] })
    ] }, l.i)) })
  ] });
}
function EvaluationBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Evaluation Committee", size: "xl", children: [
      "Evaluation team ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "members." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `mt-6 ${t.textMuted} max-w-3xl mb-16 leading-relaxed`, children: "GDSP's evaluation team brings together experienced specialists in procurement, finance, law and development — responsible for the fair, transparent and expert assessment of all supply contracts and programmes." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-1 md:grid-cols-2 gap-px ${t.divider} border ${t.border}`, children: EVALUATION.map((e) => /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: `${t.cardBg} p-8 ${t.cardBgHover} transition-colors`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-5 mb-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `size-14 border ${t.accentBorder} rounded-full flex items-center justify-center font-mono ${t.accent} shrink-0`, children: e.i }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-2xl ${t.text}`, children: e.n }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-widest ${t.accent} mt-1`, children: e.r })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed text-sm mb-5`, children: e.d }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: e.tags.map((tag) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-mono px-2 py-1 border ${t.border} ${t.textMuted}`, children: tag }, tag)) })
    ] }, e.i)) })
  ] });
}
function CTABlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-6`, children: "Work With GDSP" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: `font-display text-5xl md:text-7xl mb-8 max-w-4xl mx-auto leading-[0.95] ${t.text}`, children: [
      "Interested in partnering or ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "supplying?" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} max-w-2xl mx-auto mb-10 leading-relaxed`, children: "Our board and evaluation team are ready to assess your proposal. Whether you are a supplier, investor or development partner, GDSP provides a fair and structured pathway to engagement." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap justify-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: `${t.btnPrimary} px-8 py-5 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Contact the Board" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/supply", className: `${t.btnGhost} px-8 py-5 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Supply Procedures" })
    ] })
  ] });
}
export {
  MembersPage as component
};
