import { M as useRouter, r as reactExports, T as jsxRuntimeExports } from "./worker-entry-CxYEulTY.js";
import { L as Link } from "./router-Dbne1WUM.js";
function useLocation(opts) {
  const router = useRouter();
  {
    const location = router.stores.location.get();
    return location;
  }
}
const NAV = [
  { to: "/", label: "Home" },
  { to: "/members", label: "Our Members" },
  { to: "/supply", label: "Supply" },
  { to: "/profile", label: "Our Profile" },
  { to: "/contact", label: "Contact" }
];
function Header() {
  const loc = useLocation();
  const [open, setOpen] = reactExports.useState(false);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "relative px-6 lg:px-10 h-20 flex justify-between items-center border-b border-line bg-night/80 backdrop-blur-md sticky top-0 z-40", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "flex items-center gap-4 group", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-10 border border-gold/40 rotate-45 flex items-center justify-center transition-transform group-hover:scale-110", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-3 bg-gold -rotate-45" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-2xl leading-none tracking-tight", children: "GDSP" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[9px] font-mono uppercase tracking-[0.3em] text-bone/40 mt-1", children: "Ghana · West Africa Authority" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "hidden lg:flex gap-10 text-[13px] font-medium", children: NAV.map((item) => {
      const active = loc.pathname === item.to;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        Link,
        {
          to: item.to,
          className: active ? "text-gold relative after:content-[''] after:absolute after:-bottom-2 after:left-0 after:right-0 after:h-px after:bg-gold" : "text-bone/60 hover:text-bone transition-colors",
          children: item.label
        },
        item.to
      );
    }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "hidden lg:block", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: "/contact",
        className: "px-5 py-2 border border-gold/40 text-gold text-[11px] uppercase tracking-widest font-mono hover:bg-gold hover:text-night transition-colors",
        children: "Agent Portal"
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        className: "lg:hidden size-10 border border-line flex items-center justify-center",
        onClick: () => setOpen((v) => !v),
        "aria-label": "Toggle menu",
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block w-5 h-px bg-bone" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block w-5 h-px bg-bone" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block w-5 h-px bg-bone" })
        ] })
      }
    ),
    open && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-20 left-0 right-0 border-y border-line bg-night lg:hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col", children: NAV.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: item.to,
        onClick: () => setOpen(false),
        className: "px-6 py-4 border-b border-line/60 text-sm uppercase tracking-widest font-mono hover:text-gold",
        children: item.label
      },
      item.to
    )) }) })
  ] });
}
function Footer() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("footer", { className: "relative border-t border-line bg-deep", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 gdsp-grain opacity-50 pointer-events-none" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-[1400px] mx-auto px-6 lg:px-10 pt-20 pb-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-12 gap-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:col-span-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 mb-8", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-10 border border-gold/40 rotate-45 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-3 bg-gold -rotate-45" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-2xl leading-none", children: "GDSP" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[9px] font-mono uppercase tracking-[0.3em] text-bone/40 mt-1", children: "Ghana Development Supply Projects" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-bone/60 leading-relaxed text-sm max-w-md", children: "West Africa's premier procurement authority — overseeing infrastructure, healthcare, agriculture and consumables for over 553 million people across the sub-region." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 inline-flex items-center gap-2 px-3 py-1.5 border border-gold/40 text-gold text-[10px] font-mono uppercase tracking-[0.3em]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "size-1 rounded-full bg-gold animate-pulse" }),
            "MoU Signed · US$973.6M"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:col-span-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-[0.3em] text-gold mb-5", children: "Navigate" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-3 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "text-bone/70 hover:text-gold", children: "Home" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/members", className: "text-bone/70 hover:text-gold", children: "Our Members" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/supply", className: "text-bone/70 hover:text-gold", children: "Supply" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/profile", className: "text-bone/70 hover:text-gold", children: "Our Profile" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: "text-bone/70 hover:text-gold", children: "Contact" }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:col-span-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-[0.3em] text-gold mb-5", children: "Head Office" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("address", { className: "not-italic text-sm text-bone/70 leading-relaxed space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "F507/2 Nmetsobu Street" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "Near Simbins Furniture" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "Sekondi, Takoradi" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "Western Region, Republic of Ghana" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 space-y-2 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "tel:+233561195994", className: "block text-bone hover:text-gold", children: "+233 (0) 561 195 994" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "mailto:info@gdspghana.org", className: "block text-bone hover:text-gold", children: "info@gdspghana.org" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-16 pt-8 border-t border-line flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-[10px] font-mono uppercase tracking-[0.3em] text-bone/40", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "© ",
          (/* @__PURE__ */ new Date()).getFullYear(),
          " Ghana Development Supply Projects · All rights reserved"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Republic of Ghana" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Est. 2014" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gold", children: "Vision 2030" })
        ] })
      ] })
    ] })
  ] });
}
function TopBar() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative border-b border-line px-6 lg:px-10 py-3 flex flex-col md:flex-row gap-2 md:gap-0 justify-between items-center text-[10px] font-mono uppercase tracking-[0.3em] text-bone/60", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-x-8 gap-y-1 justify-center md:justify-start", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "F507/2 Nmetsobu Street · Sekondi-Takoradi" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden md:inline", children: "info@gdspghana.org" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden lg:inline", children: "+233 (0) 561 195 994" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-gold", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "size-1 rounded-full bg-gold animate-pulse" }),
      "MoU Signed · US$973.6M"
    ] })
  ] });
}
const ToneCtx = reactExports.createContext("dark");
const useSectionTone = () => reactExports.useContext(ToneCtx);
const FlowCtx = reactExports.createContext(null);
function SectionFlow({ children, start = "dark" }) {
  const counter = { i: 0, start };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(FlowCtx.Provider, { value: counter, children });
}
const padMap = {
  default: "px-6 lg:px-10 py-32",
  tight: "px-6 lg:px-10 py-24",
  none: ""
};
function Section({
  children,
  tone,
  className = "",
  bare = false,
  padding = "default",
  atmosphere = "none",
  unmanaged = false
}) {
  const flow = reactExports.useContext(FlowCtx);
  let resolved = tone ?? "dark";
  if (!tone && !unmanaged && flow) {
    const idx = flow.i++;
    resolved = idx % 2 === 0 ? flow.start : flow.start === "dark" ? "light" : "dark";
  }
  const surface = resolved === "light" ? "gdsp-light border-y border-night/10" : "bg-night text-bone border-y border-line";
  const atmoClass = atmosphere === "none" ? "" : resolved === "light" ? atmosphere === "grid" ? "gdsp-light-grid opacity-50" : "gdsp-light-spot" : atmosphere === "grid" ? "gdsp-grid opacity-50" : "gdsp-spot";
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ToneCtx.Provider, { value: resolved, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: `relative overflow-hidden ${surface} ${className}`, children: [
    atmosphere !== "none" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `absolute inset-0 pointer-events-none ${atmoClass}` }),
    resolved === "light" && atmosphere === "none" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 gdsp-light-grain opacity-50 pointer-events-none" }),
    bare ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative", children }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `relative max-w-[1400px] mx-auto ${padMap[padding]}`, children })
  ] }) });
}
function useToneTokens() {
  const tone = useSectionTone();
  const dark = tone === "dark";
  return {
    tone,
    text: dark ? "text-bone" : "text-night",
    textMuted: dark ? "text-bone/70" : "text-night/70",
    textFaint: dark ? "text-bone/50" : "text-night/55",
    accent: dark ? "text-gold" : "text-clay",
    accentBorder: dark ? "border-gold" : "border-clay",
    border: dark ? "border-line" : "border-night/15",
    divider: dark ? "bg-line" : "bg-night/15",
    cardBg: dark ? "bg-night" : "bg-bone",
    cardBgHover: dark ? "hover:bg-deep" : "hover:bg-white",
    softCardBg: dark ? "bg-deep/40" : "bg-white/70",
    btnPrimary: dark ? "bg-gold text-night hover:bg-bone" : "bg-night text-bone hover:bg-clay",
    btnGhost: dark ? "border border-bone/20 text-bone hover:border-gold hover:text-gold" : "border border-night/30 text-night hover:border-clay hover:text-clay"
  };
}
function SectionHeading({
  eyebrow,
  children,
  size = "lg",
  className = ""
}) {
  const t = useToneTokens();
  const sizeClass = size === "xl" ? "text-5xl md:text-7xl" : size === "md" ? "text-4xl md:text-5xl" : "text-5xl md:text-6xl";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className, children: [
    eyebrow && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-6`, children: eyebrow }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: `font-display ${sizeClass} leading-[0.95] ${t.text}`, children })
  ] });
}
export {
  Footer as F,
  Header as H,
  SectionFlow as S,
  TopBar as T,
  Section as a,
  SectionHeading as b,
  useToneTokens as u
};
