import { T as jsxRuntimeExports } from "./worker-entry-CxYEulTY.js";
import { L as Link } from "./router-Dbne1WUM.js";
import { T as TopBar, H as Header, S as SectionFlow, a as Section, F as Footer, u as useToneTokens, b as SectionHeading } from "./Section-DwmYnCaZ.js";
import { P as PageHero } from "./PageHero-BbZQIVuv.js";
import "node:events";
import "node:async_hooks";
import "node:stream/web";
import "node:stream";
const SECTORS = ["Peace & Security", "Political Affairs", "Infrastructure & Energy", "Social Development", "Women & Gender", "Tender Verification", "Trade & Industry", "Rural Economy", "Agriculture", "Legal Affairs", "Human Resources", "Science & Technology"];
const MILESTONES = [{
  y: "2014",
  t: "GDSP Established",
  d: "Founded as a centralised procurement agency for the Government of Ghana, providing legal and institutional framework for public procurement."
}, {
  y: "Jul 2020",
  t: "Project Financing Summit (PFS)",
  d: "Key stakeholders mobilised to accelerate implementation of PIDA — including DFIs, private equity investors, infrastructure funds, commercial banks and pension funds."
}, {
  y: "Nov 2020",
  t: "MoU Agreements Signed",
  d: "Agreements signed with donor agencies valued at US$973.6 Million, plus an economic grant of US$756.2 Million to strengthen regional stability."
}, {
  y: "2021—Now",
  t: "16 Strategic PIDA Projects",
  d: "Selected 16 strategic, regionally balanced projects from the PIDA Priority Action Plan to drive implementation across the project development cycle."
}, {
  y: "2030",
  t: "Ghana Vision 2030",
  d: "Committed to Ghana's Year-2030 Vision — accelerating infrastructure, promoting ethical tendering, and building a competitive, integrated African economy."
}];
const VALUES = [{
  t: "Respect for Diversity & Teamwork",
  d: "Honouring the full spectrum of perspectives and working collaboratively across borders, cultures and disciplines to achieve shared goals."
}, {
  t: "Think Africa Above All",
  d: "Every decision, programme and partnership is evaluated through the lens of what benefits Africa and its people most broadly and sustainably."
}, {
  t: "Transparency & Accountability",
  d: "Operating openly, reporting honestly and holding ourselves to the highest standards of accountability in every procurement and programme we manage."
}, {
  t: "Integrity & Impartiality",
  d: "Upholding ethical conduct in every evaluation, contract and relationship — treating all suppliers, partners and stakeholders fairly and without bias."
}, {
  t: "Efficiency & Professionalism",
  d: "Delivering value through streamlined processes, skilled personnel and a commitment to continuous improvement across all operational areas."
}, {
  t: "Information & Knowledge Sharing",
  d: "Fostering a culture of open communication where market intelligence, research and operational knowledge flow freely to inform better decisions."
}];
const PRINCIPLES = ["Subsidiary and complementarity with other Organs, Member States and Regional Economic Communities (RECs).", "Results orientation, feasibility and impact focus — ensuring every programme delivers measurable real-world outcomes.", "Close coordination and cooperation with the Regional Economic Communities across West Africa and the broader continent.", "Coherence of policies and programmes — aligning all activities with national, regional and continental development strategies.", "A networking approach that takes full advantage of available resources through collaboration with other players and institutions."];
const MANDATES = [{
  t: "International Relations",
  d: "To develop and maintain constructive and productive institutional relationships between Africa and the rest of the world, and to coordinate the mobilisation of extra-budgetary resources."
}, {
  t: "Strategic Planning & Evaluation",
  d: "To ensure inter-departmental coordination in strategic planning, continuous monitoring and evaluation of programme outputs against action plans, and to assess the efficiency and effectiveness of programmes in realising organisational goals."
}, {
  t: "Research & Statistics",
  d: "To provide and maintain research and statistical services catering for the needs of the entire Commission, other Organs of the Union, RECs and Member States — ensuring data-driven decision making."
}];
const FUNCTIONS = ["Prepare rules and procedures for policy formulation, coordination and evaluation.", "Promote internal best practices concerning strategic planning, monitoring projects and evaluation.", "Survey and propose overall operational priorities of the Commission to guide effective resource allocation.", "Assist Directorates and Offices to develop strategic planning skills and institutional capacity.", "Organise coordination meetings on policy formulation and strategic planning across departments.", "Lead and provide support for sectorial research projects, and ensure their effective implementation.", "Develop and manage Research and Statistics Services for the Union and member institutions.", "Prepare the Annual Report of the Commission to ensure accountability and transparency.", "Produce an approved annual statement on general orientations and priorities relating to operational programmes.", "Propose training programmes relating to programme designing and programme coordination.", "Ensure that the Statistics Unit is accessible to all Organs and Member States with updated information.", "Design and implement monitoring and evaluation procedures for assessing programme achievements.", "Strengthen existing relations and develop relations with other world regions for mutual cooperation.", "Seek new areas of cooperation with international partners to expand GDSP's reach and impact.", "Promote a positive image of Africa within the international arena through engagement.", "Popularise the African Union and market its programmes and activities to a wider global audience.", "Initiate, develop and manage policy for international cooperation and resource mobilisation.", "Coordinate and develop strategies for resource mobilisation aligned with organisational priorities.", "Coordinate the process of proposal and project formulation for new programmes and initiatives.", "Coordinate the process of project and programme monitoring and evaluation throughout the lifecycle.", "Develop an outline for progress reports to ensure consistent and transparent performance tracking.", "Initiate, develop and manage strategies for sustainability, self-financing, income generation and investment.", "Facilitate logistical support to coordinate interaction with partners, donors and member institutions."];
function ProfilePage() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-dvh bg-night text-bone", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(TopBar, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Header, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHero, { eyebrow: "About GDSP", breadcrumb: "Our Profile", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "Our ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: "text-gold not-italic", children: "profile." })
    ] }), intro: "Ghana Development Supply Projects was established to provide a legal, institutional and professional framework for public procurement — serving the people of Ghana and the West African sub-region with accountability and integrity." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "gdsp-bright-band border-b border-night/10", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-[1400px] mx-auto grid grid-cols-2 lg:grid-cols-4 divide-x divide-y lg:divide-y-0 divide-night/15", children: [{
      v: "2014",
      l: "Established"
    }, {
      v: "12+",
      l: "Sectors Served"
    }, {
      v: "23",
      l: "Core Functions"
    }, {
      v: "2030",
      l: "Vision Year"
    }].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 lg:p-10 hover:bg-white/55 transition-colors", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-[0.3em] text-clay mb-5", children: s.l }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-5xl tabular-nums text-night", children: s.v })
    ] }, s.l)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionFlow, { start: "light", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "spot", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AboutBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { padding: "tight", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MilestonesBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "spot", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MissionBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { padding: "tight", children: /* @__PURE__ */ jsxRuntimeExports.jsx(PrinciplesBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "grid", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FunctionsBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CommitmentBlock, {}) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
function AboutBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-16", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-5", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "About GDSP", children: [
        "Established to serve ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "Ghana & West Africa." })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `lg:col-span-7 space-y-5 text-lg ${t.textMuted} leading-relaxed`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "The Ghana Development Supply Project (GDSP) was originally established in 2014 as a centralised procurement agency for the Government of Ghana — to carry out the responsibility of Government Supply Orders and provide a legal, institutional and professional framework for public procurement." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Infrastructure development is a key driver for progress across the African continent and a critical enabler for sustainable and socially inclusive growth. GDSP operates within the Program for Infrastructure Development (PIDA) — the strategic framework transforming Africa through modern, interconnected infrastructure." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "We remain committed to supporting Ghana's Year-2030 Vision by accelerating infrastructure projects, supporting economic development, and becoming a global benchmark for ethical and effective tendering practices." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-20", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-6`, children: "Sectors We Contract For" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: SECTORS.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `px-4 py-2 border ${t.border} text-sm ${t.text} transition-colors ${t.tone === "dark" ? "hover:border-gold hover:text-gold" : "hover:border-clay hover:text-clay"}`, children: s }, s)) })
    ] })
  ] });
}
function MilestonesBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Key Milestones", size: "xl", className: "mb-16", children: [
      "A timeline of ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "impact." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `space-y-px ${t.divider} border ${t.border}`, children: MILESTONES.map((m, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-8 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 ${t.cardBgHover} transition-colors`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `lg:col-span-2 text-[10px] font-mono uppercase tracking-widest ${t.textFaint}`, children: [
        String(i + 1).padStart(2, "0"),
        " / ",
        MILESTONES.length
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `lg:col-span-3 font-display text-3xl ${t.accent}`, children: m.y }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-7", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-2xl mb-2 ${t.text}`, children: m.t }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed`, children: m.d })
      ] })
    ] }, m.y)) })
  ] });
}
function MissionBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Mission & Values", size: "xl", className: "mb-12", children: [
      "What guides everything ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "we do." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("blockquote", { className: `font-display text-3xl md:text-5xl leading-[1.1] max-w-5xl border-l-2 ${t.accentBorder} pl-8 mb-20 ${t.text}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: t.accent, children: '"' }),
      "An efficient and value-adding institution driving the Ghana integration and development process in close collaboration with African Union Member States, the Regional Economic Communities and African citizens.",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: t.accent, children: '"' })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px ${t.divider} border ${t.border}`, children: VALUES.map((v, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-8 group ${t.cardBgHover} transition-colors`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-display text-4xl ${t.tone === "dark" ? "text-gold/30 group-hover:text-gold" : "text-clay/40 group-hover:text-clay"} transition-colors mb-4`, children: String(i + 1).padStart(2, "0") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-2xl mb-3 ${t.text}`, children: v.t }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed text-sm`, children: v.d })
    ] }, v.t)) })
  ] });
}
function PrinciplesBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-6`, children: "Guiding Principles" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-4xl mb-10 ${t.text}`, children: "How we operate." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ol", { className: "space-y-6", children: PRINCIPLES.map((p, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: `flex gap-6 border-b ${t.border} pb-6`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-display text-3xl ${t.accent} tabular-nums shrink-0`, children: String(i + 1).padStart(2, "0") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed`, children: p })
      ] }, i)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.accent} mb-6`, children: "Our Mandate" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-4xl mb-10 ${t.text}`, children: "Three pillars." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `space-y-px ${t.divider} border ${t.border}`, children: MANDATES.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-8`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: `font-display text-2xl mb-3 ${t.text}`, children: m.t }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} leading-relaxed text-sm`, children: m.d })
      ] }, m.t)) })
    ] })
  ] });
}
function FunctionsBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Core Functions", size: "xl", children: [
      "23 operational ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "functions." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `mt-6 ${t.textMuted} max-w-3xl mb-16 leading-relaxed`, children: "The following functions define how GDSP delivers on its mandate — from policy formulation and strategic planning to international cooperation, resource mobilisation and programme evaluation." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px ${t.divider} border ${t.border}`, children: FUNCTIONS.map((f, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${t.cardBg} p-6 group ${t.cardBgHover} transition-colors`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[10px] font-mono uppercase tracking-widest ${t.accent} mb-3 tabular-nums`, children: [
        "Function ",
        String(i + 1).padStart(2, "0")
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-sm ${t.textMuted} leading-relaxed`, children: f })
    ] }, i)) })
  ] });
}
function CommitmentBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Our Commitment", size: "xl", className: "mb-12", children: [
      "Building a better ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "Ghana — together." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `space-y-6 text-lg ${t.textMuted} leading-relaxed max-w-4xl`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "The Commission will endeavour to fulfil its Mission by developing clear goals and strategies. Guided by our values and principles, we commit the requisite resources for effective discharge of our mandate — presenting specific proposals that bring new possibilities and benefits to the citizens of Africa." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Ghana Development Supply Projects is focused on making development projects in Ghana easier and more efficient. We believe Ghana can become a global benchmark for ethical and effective tendering practices — because together, we can build a better Ghana." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textFaint} italic`, children: "A service culture of excellence, developed through consistent application of our values, will be the foundation on which GDSP achieves its mission for the next decade and beyond." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-12 flex flex-wrap gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/supply", className: `${t.btnPrimary} px-7 py-4 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Explore Supply" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: `${t.btnGhost} px-7 py-4 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Get in Touch" })
    ] })
  ] });
}
export {
  ProfilePage as component
};
