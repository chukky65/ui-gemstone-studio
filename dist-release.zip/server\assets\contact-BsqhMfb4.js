import { T as jsxRuntimeExports, r as reactExports } from "./worker-entry-CxYEulTY.js";
import { T as TopBar, H as Header, S as SectionFlow, a as Section, F as Footer, u as useToneTokens, b as SectionHeading } from "./Section-DwmYnCaZ.js";
import { P as PageHero } from "./PageHero-BbZQIVuv.js";
import "node:events";
import "node:async_hooks";
import "node:stream/web";
import "node:stream";
import "./router-Dbne1WUM.js";
const ENQUIRY_TYPES = ["Supplier Registration", "Investment / Partnership", "Healthcare Supply", "Infrastructure Project", "Agricultural Supply", "Agent Accreditation", "General Enquiry", "Other"];
const COUNTRIES = ["Ghana", "Nigeria", "South Africa", "Angola", "Ivory Coast", "Senegal", "Kenya", "United Kingdom", "United States", "China", "Other"];
function ContactPage() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-dvh bg-night text-bone", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(TopBar, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Header, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHero, { eyebrow: "Get In Touch", breadcrumb: "Contact Us", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "Contact ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: "text-gold not-italic", children: "GDSP." })
    ] }), intro: "Whether you are a supplier, investor, partner organisation or member of the public — we welcome your enquiry. Our team is ready to assist you." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "gdsp-bright-band border-b border-night/10", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-[1400px] mx-auto grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-night/15", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-10", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-[0.3em] text-clay mb-5", children: "Mail Address" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-2xl mb-3 text-night", children: "Physical Address" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("address", { className: "not-italic text-night/70 leading-relaxed text-sm", children: [
          "F507/2 Nmetsobu Street",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Near Simbins Furniture",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Sekondi, Takoradi",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "W/R, Republic of Ghana"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-10", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-[0.3em] text-clay mb-5", children: "Contact Information" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-widest text-night/45 mb-1", children: "Phone" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "tel:+233561195994", className: "font-display text-xl hover:text-clay text-night", children: "+233 (0) 561 195 994" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-widest text-night/45 mb-1", children: "Official Email" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "mailto:info@ghsupplyprojects.org", className: "text-night hover:text-clay break-all", children: "info@ghsupplyprojects.org" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-widest text-night/45 mb-1", children: "Project Email" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "mailto:ghdevelopmentsupplyproject@gmail.com", className: "text-night hover:text-clay break-all text-sm", children: "ghdevelopmentsupplyproject@gmail.com" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-10", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-mono uppercase tracking-[0.3em] text-clay mb-5", children: "Office Hours" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-3 text-sm text-night", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex justify-between border-b border-night/15 pb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Mon — Fri" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-clay", children: "8:00 AM — 5:00 PM" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex justify-between border-b border-night/15 pb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Saturday" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-night/70", children: "9:00 AM — 1:00 PM" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex justify-between border-b border-night/15 pb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sunday" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-night/45", children: "Closed" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Public Holidays" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-night/45", children: "Closed" })
          ] })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionFlow, { start: "light", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { atmosphere: "spot", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FormBlock, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Section, { padding: "tight", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LocationBlock, {}) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
function FormBlock() {
  const t = useToneTokens();
  const [sent, setSent] = reactExports.useState(false);
  const focusClass = t.tone === "dark" ? "focus-visible:border-gold focus-visible:ring-2 focus-visible:ring-gold/35" : "focus-visible:border-clay focus-visible:ring-2 focus-visible:ring-clay/35";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Send Us a Message", children: [
        "We respond within ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "2 business days." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `mt-6 ${t.textMuted} leading-relaxed`, children: "Complete the form and our team will review your enquiry. For supplier registrations please be ready to share your company details and quotation invoice." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-7", children: sent ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `border ${t.accentBorder} p-12 text-center ${t.softCardBg}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `size-16 mx-auto mb-6 border-2 ${t.accentBorder} rounded-full flex items-center justify-center ${t.accent} text-3xl`, children: "✓" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-display text-3xl mb-3 ${t.text}`, children: "Message Sent Successfully" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${t.textMuted} mb-8`, children: "Thank you for reaching out to GDSP. A member of our team will review your enquiry and respond within 2 business days." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setSent(false), className: `${t.btnGhost} px-6 py-3 text-[11px] font-mono uppercase tracking-widest transition-colors`, children: "Send Another" })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: (e) => {
      e.preventDefault();
      setSent(true);
    }, className: `border ${t.border} p-8 lg:p-10 ${t.softCardBg} backdrop-blur-sm space-y-6`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "First Name *", name: "firstName", required: true, tone: t, focusClass }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Last Name *", name: "lastName", required: true, tone: t, focusClass }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Email Address *", name: "email", type: "email", required: true, tone: t, focusClass }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Phone Number", name: "phone", tone: t, focusClass }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Organisation / Company", name: "org", tone: t, focusClass }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Select, { label: "Country / Region", name: "country", options: ["Select your country", ...COUNTRIES], tone: t, focusClass })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Select, { label: "Enquiry Type *", name: "enquiry", options: ["Select the nature of your enquiry", ...ENQUIRY_TYPES], required: true, tone: t, focusClass }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "message", className: `block text-[10px] font-mono uppercase tracking-[0.3em] ${t.textMuted} mb-2`, children: "Your Message *" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { id: "message", name: "message", required: true, rows: 5, className: `w-full ${t.cardBg} border ${t.border} ${t.text} p-4 ${focusClass} focus-visible:outline-none resize-none` })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: `flex items-start gap-3 text-xs ${t.textMuted} cursor-pointer`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", required: true, className: `mt-1 ${t.tone === "dark" ? "accent-gold" : "accent-clay"}` }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "I agree that GDSP may contact me regarding my enquiry. I have read and accept the Privacy Policy and Terms of Use." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "submit", className: `w-full ${t.btnPrimary} px-7 py-5 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Send Enquiry →" })
    ] }) })
  ] });
}
function LocationBlock() {
  const t = useToneTokens();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-12 items-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(SectionHeading, { eyebrow: "Our Location", children: [
        "Find us in ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("em", { className: `${t.accent} not-italic`, children: "Takoradi." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `mt-6 ${t.textMuted} leading-relaxed mb-8`, children: "We are located in Sekondi-Takoradi, Ghana's industrial capital and a key hub for West African trade." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `border ${t.border} p-6 ${t.cardBg} mb-6`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-widest ${t.accent} mb-3`, children: "GDSP Head Office" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("address", { className: `not-italic ${t.textMuted} leading-relaxed text-sm`, children: [
          "Ghana Development Supply Projects",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "F507/2 Nmetsobu Street",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Near Simbins Furniture",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Sekondi, Takoradi · W/R, Ghana"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://maps.google.com/?q=Sekondi-Takoradi,Ghana", target: "_blank", rel: "noopener noreferrer", className: `inline-flex items-center gap-3 ${t.btnPrimary} px-7 py-4 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors`, children: "Get Directions →" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-7", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `aspect-[4/3] relative border ${t.border} ${t.cardBg} overflow-hidden`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `absolute inset-0 ${t.tone === "dark" ? "gdsp-grid" : "gdsp-light-grid"} opacity-50` }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `size-20 mx-auto border-2 ${t.accentBorder} rounded-full flex items-center justify-center mb-4`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `size-3 ${t.tone === "dark" ? "bg-gold" : "bg-clay"} rounded-full animate-pulse` }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-display text-3xl ${t.accent} mb-2`, children: "Sekondi-Takoradi" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] font-mono uppercase tracking-[0.3em] ${t.textMuted}`, children: "Western Region · Republic of Ghana" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `absolute top-4 left-4 text-[10px] font-mono uppercase tracking-widest ${t.accent} opacity-60`, children: "04°53′N · 01°45′W" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `absolute bottom-4 right-4 text-[10px] font-mono uppercase tracking-widest ${t.accent} opacity-60`, children: "GDSP HQ" })
    ] }) })
  ] });
}
function Field({
  label,
  name,
  type = "text",
  required,
  tone,
  focusClass
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: name, className: `block text-[10px] font-mono uppercase tracking-[0.3em] ${tone.textMuted} mb-2`, children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { id: name, name, type, required, className: `w-full ${tone.cardBg} border ${tone.border} ${tone.text} px-4 py-3 ${focusClass} focus-visible:outline-none` })
  ] });
}
function Select({
  label,
  name,
  options,
  required,
  tone,
  focusClass
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: name, className: `block text-[10px] font-mono uppercase tracking-[0.3em] ${tone.textMuted} mb-2`, children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("select", { id: name, name, required, className: `w-full ${tone.cardBg} border ${tone.border} ${tone.text} px-4 py-3 ${focusClass} focus-visible:outline-none`, children: options.map((o, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: i === 0 ? "" : o, disabled: i === 0, children: o }, o)) })
  ] });
}
export {
  ContactPage as component
};
