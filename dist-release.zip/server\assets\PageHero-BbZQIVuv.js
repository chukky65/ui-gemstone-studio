import { T as jsxRuntimeExports } from "./worker-entry-CxYEulTY.js";
import { L as Link } from "./router-Dbne1WUM.js";
function PageHero({ eyebrow, title, intro, breadcrumb }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative border-b border-line overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 gdsp-grain pointer-events-none" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 gdsp-spot pointer-events-none" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-[1400px] mx-auto px-6 lg:px-10 pt-20 pb-24", children: [
      breadcrumb && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-8 text-[10px] font-mono uppercase tracking-[0.3em] text-bone/40", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "hover:text-gold", children: "Home" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mx-3 text-gold", children: "›" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-bone/70", children: breadcrumb })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mb-8 text-gold", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-px bg-gold" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-mono uppercase tracking-[0.4em]", children: eyebrow })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "gdsp-rise font-display text-6xl md:text-8xl leading-[0.9] tracking-tight max-w-5xl", children: title }),
      intro && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-10 text-lg md:text-xl text-bone/70 max-w-3xl leading-relaxed", children: intro })
    ] })
  ] });
}
export {
  PageHero as P
};
